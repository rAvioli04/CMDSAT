import mpu6050
import time

mpu6050 = mpu6050.mpu6050(0x68)

def read_sensor_data():
    accel_data = mpu6050.get_accel_data()
    gyro_data = mpu6050.get_gyro_data()
    return accel_data, gyro_data

while True:
    accel_data, gyro_data = read_sensor_data()
    print("ACCEL DATA: " , accel_data)
    print("gyroDATA: " , gyro_data)
    
    time.sleep(1)
    