import sys
import time
import os

import odrive
import cv2 as cv

# Setting up camera settings
cam_port = 0

#Setting up motor settings/configuration
class HBMotorConfig:
    """
    Class for configuring an Odrive axis for a Hoverboard motor.
    Only works with one Odrive at a time.
    """

    def __init__(self, axis_num):
        """
        Initalizes HBMotorConfig class by finding odrive, erase its
        configuration, and grabbing specified axis object.

        :param axis_num: Which channel/motor on the odrive your referring to.
        :type axis_num: int (0 or 1)
        :param erase_config: Erase existing config before setting new config.
        :type erase_config: bool (True or False)
        """

        self.axis_num = axis_num

        # Connect to Odrive
        print("Looking for ODrive...")
        self._find_odrive()
        print("Found ODrive.")

    def _find_odrive(self):
        # connect to Odrive
        self.odrv = odrive.find_any()
        self.odrv_axis = getattr(self.odrv, "axis{}".format(self.axis_num)) 

    def mode_idle(self):
        """
        Puts the motor in idle (i.e. can move freely).
        """
        #idle=1
        self.odrv_axis.requested_state = 1

    def mode_close_loop_control(self):
        """
        Puts the motor in closed loop control.
        """
        #closed loop control=8
        self.odrv_axis.requested_state = 8

    def move_input_pos(self, angle):
        """
        Puts the motor at a certain angle.

        :param angle: Angle you want the motor to move.
        :type angle: int or float
        """

        self.odrv_axis.controller.input_pos = angle / 360.0
    def full_cal(self):
        """
        Does a full calibration of the motor
        """
        self.odrv_axis.requested_state = 3

if __name__ == "__main__":

    hb_motor_config = HBMotorConfig(axis_num=0)

    # Calibration of the motor 
    # Only run once after turning on the motor
    print("Calibration of the motor")
    hb_motor_config.full_cal()
    time.sleep(20)

    # Putting the motor in close loop control to be able to change its position
    print("Placing motor in close loop. If you move motor, motor will resist you.")
    hb_motor_config.mode_close_loop_control()

    print("CONDUCTING MOTOR AND CAMERA TEST")

    # Changing file path to save photos to correct location
    path = "/home/pi/Desktop/OdessaMasters/Photos"

    # Go from 0 to 360 degrees in increments of 60 degrees and taking a photo every 60 degrees
    for angle in range(0, 450, 90):
        print("Setting motor to {} degrees.".format(angle))
        hb_motor_config.move_input_pos(angle)
        time.sleep(4)

        print("Capturing photo")
        # Start capturing data from camera
        cam = cv.VideoCapture(cam_port)
        result, image = cam.read() 
        time.sleep(20)
        print("Writing image")
        cv.imwrite(os.path.join(path , "Cam pic angle {}.png".format(angle)), image)
        time.sleep(20)

        # Stop camera recording
        cam.release()
        print("Camera released")


    print("Placing motor in idle. If you move motor, motor will move freely")
    hb_motor_config.mode_idle()
