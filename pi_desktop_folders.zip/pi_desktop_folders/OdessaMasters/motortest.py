import argparse
import sys
import time

import odrive

class HBMotorConfig:
    """
    Class for configuring an Odrive axis for a Hoverboard motor.
    Only works with one Odrive at a time.
    """

    def __init__(self, axis_num):
        """
        Initalizes HBMotorConfig class by finding odrive, erase its
        configuration, and grabbing specified axis object.

        :param axis_num: Which channel/motor on the odrive your referring to.
        :type axis_num: int (0 or 1)
        :param erase_config: Erase existing config before setting new config.
        :type erase_config: bool (True or False)
        """

        self.axis_num = axis_num

        # Connect to Odrive
        print("Looking for ODrive...")
        self._find_odrive()
        print("Found ODrive.")

    def _find_odrive(self):
        # connect to Odrive
        self.odrv = odrive.find_any()
        self.odrv_axis = getattr(self.odrv, "axis{}".format(self.axis_num))

    def configure(self):
        """
        Configures the odrive device for a hoverboard motor.
        """

        self._find_odrive()

        input("Make sure the motor is free to move, then press enter...")

        print("Calibrating Odrive for hoverboard motor (you should hear a " "beep)...")
        #motor calibration=4
        self.odrv_axis.requested_state = 4

        # Wait for calibration to take place
        time.sleep(10)

        if self.odrv_axis.motor.error != 0:
            print(
                "Error: Odrive reported an error of {} while in the state "
                "AXIS_STATE_MOTOR_CALIBRATION. Printing out Odrive motor data for "
                "debug:\n{}".format(self.odrv_axis.motor.error, self.odrv_axis.motor)
            )

            sys.exit(1)

        if (
            self.odrv_axis.motor.config.phase_inductance <= self.MIN_PHASE_INDUCTANCE
            or self.odrv_axis.motor.config.phase_inductance >= self.MAX_PHASE_INDUCTANCE
        ):
            print(
                "Error: After odrive motor calibration, the phase inductance "
                "is at {}, which is outside of the expected range. Either widen the "
                "boundaries of MIN_PHASE_INDUCTANCE and MAX_PHASE_INDUCTANCE (which "
                "is between {} and {} respectively) or debug/fix your setup. Printing "
                "out Odrive motor data for debug:\n{}".format(
                    self.odrv_axis.motor.config.phase_inductance,
                    self.MIN_PHASE_INDUCTANCE,
                    self.MAX_PHASE_INDUCTANCE,
                    self.odrv_axis.motor,
                )
            )

            sys.exit(1)

        if (
            self.odrv_axis.motor.config.phase_resistance <= self.MIN_PHASE_RESISTANCE
            or self.odrv_axis.motor.config.phase_resistance >= self.MAX_PHASE_RESISTANCE
        ):
            print(
                "Error: After odrive motor calibration, the phase resistance "
                "is at {}, which is outside of the expected range. Either raise the "
                "MAX_PHASE_RESISTANCE (which is between {} and {} respectively) or "
                "debug/fix your setup. Printing out Odrive motor data for "
                "debug:\n{}".format(
                    self.odrv_axis.motor.config.phase_resistance,
                    self.MIN_PHASE_RESISTANCE,
                    self.MAX_PHASE_RESISTANCE,
                    self.odrv_axis.motor,
                )
            )

            sys.exit(1)

        # If all looks good, then lets tell ODrive that saving this calibration
        # to persistent memory is OK
        self.odrv_axis.motor.config.pre_calibrated = True



        print("Calibrating Odrive for encoder offset...")
        #encoder offset calibration=7
        self.odrv_axis.requested_state = 7

        # Wait for calibration to take place
        time.sleep(30)

        if self.odrv_axis.encoder.error != 0:
            print(
                "Error: Odrive reported an error of {} while in the state "
                "AXIS_STATE_ENCODER_OFFSET_CALIBRATION. Printing out Odrive encoder "
                "data for debug:\n{}".format(
                    self.odrv_axis.encoder.error, self.odrv_axis.encoder
                )
            )

            sys.exit(1)

        # If all looks good, then lets tell ODrive that saving this calibration
        # to persistent memory is OK
        self.odrv_axis.encoder.config.pre_calibrated = True

        print("Calibrating Odrive for anticogging...")
        #closed loop control=8
        self.odrv_axis.requested_state = 8

        self.odrv_axis.controller.start_anticogging_calibration()

        while self.odrv_axis.controller.config.anticogging.calib_anticogging:
            time.sleep(15)
            print("Still calibrating anticogging...")

        if self.odrv_axis.controller.error != 0:
            print(
                "Error: Odrive reported an error of {} while performing "
                "start_anticogging_calibration(). Printing out Odrive controller "
                "data for debug:\n{}".format(
                    self.odrv_axis.controller.error, self.odrv_axis.controller
                )
            )

            sys.exit(1)

        # If all looks good, then lets tell ODrive that saving this calibration
        # to persistent memory is OK
        self.odrv_axis.controller.config.anticogging.pre_calibrated = True

        # Motors must be in IDLE mode before saving
        #idle=1
        self.odrv_axis.requested_state = 1

        self._find_odrive()

        print("Odrive configuration finished.")    

    def mode_idle(self):
        """
        Puts the motor in idle (i.e. can move freely).
        """
        #idle=1
        self.odrv_axis.requested_state = 1

    def mode_close_loop_control(self):
        """
        Puts the motor in closed loop control.
        """
        #closed loop control=8
        self.odrv_axis.requested_state = 8

    def move_input_pos(self, angle):
        """
        Puts the motor at a certain angle.

        :param angle: Angle you want the motor to move.
        :type angle: int or float
        """

        self.odrv_axis.controller.input_pos = angle / 360.0
    def full_cal(self):
        """
        Does a full calibration of the motor
        """
        self.odrv_axis.requested_state = 3


if __name__ == "__main__":
    # parser = argparse.ArgumentParser(description="Hoverboard Motor Calibration")

    # # Argument for axis_num
    # parser.add_argument(
    #     "--axis_num",
    #     type=int,
    #     choices=[0, 1],  # Only allow 0 or 1
    #     required=True,
    #     help="Motor axis number which can only be 0 or 1.",
    # )

    # # Argument to conduct motor test (make sure motor can move freely)
    # parser.add_argument(
    #     "--motor_test",
    #     action="store_true",  # If present, set to True. If absent, set to False.
    #     help="Flag to determine if the config should be erased.",
    # )

    # args = parser.parse_args()

    hb_motor_config = HBMotorConfig(
        axis_num=0
    )
    # hb_motor_config.configure()
    
    # hb_motor_config.full_cal()
    # time.sleep(20)

    print("Placing motor in close loop. If you move motor, motor will resist you.")
    hb_motor_config.mode_close_loop_control()

    print("CONDUCTING MOTOR TEST")

    # Go from 0 to 360 degrees in increments of 30 degrees
    for angle in range(0, 390, 90):
        print("Setting motor to {} degrees.".format(angle))
        hb_motor_config.move_input_pos(angle)
        time.sleep(5)

    print("Placing motor in idle. If you move motor, motor will move freely")
    hb_motor_config.mode_idle()