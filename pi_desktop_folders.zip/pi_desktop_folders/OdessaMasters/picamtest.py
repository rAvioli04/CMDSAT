import time
import cv2 as cv

# Setting up camera settings
cam_port = 0



for angle in range(0, 270, 90):

	print("Capturing photo")
	cam = cv.VideoCapture(cam_port)
	result, image = cam.read() 
	cv.imshow('Cam pic angle {}.png'.format(angle), image)
	time.sleep(15)
	print("Writing image")
	cv.imwrite('Cam pic angle {}.png'.format(angle), image)
	time.sleep(20)
	cam.release()
	print("Camera released")
	

